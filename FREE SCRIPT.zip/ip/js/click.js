// code for activate clicked sound
var buka = new Audio();
buka.src = "media/open.mp3";

var tutup = new Audio();
tutup.src = "media/close.mp3";

var blok = new Audio();
blok.src = "media/se3low.mp3";

function open_once_rewards1() {
  $(".once_rewards1").show();
  $(".itemReward_confirmation").hide();
}
function open_once_rewards2() {
  $(".once_rewards2").show();
  $(".itemReward_confirmation").hide();
}
function open_once_rewards3() {
  $(".once_rewards3").show();
  $(".itemReward_confirmation").hide();
}
function open_once_rewards4() {
  $(".once_rewards4").show();
  $(".itemReward_confirmation").hide();
}
function open_once_rewards5() {
  $(".once_rewards5").show();
  $(".itemReward_confirmation").hide();
}
function open_once_rewards6() {
  $(".once_rewards6").show();
  $(".itemReward_confirmation").hide();
}
function open_once_rewards7() {
  $(".once_rewards7").show();
  $(".itemReward_confirmation").hide();
}
function open_once_rewards8() {
  $(".once_rewards8").show();
  $(".itemReward_confirmation").hide();
}
function open_once_rewards9() {
  $(".once_rewards9").show();
  $(".itemReward_confirmation").hide();
}
