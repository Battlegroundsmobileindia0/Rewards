<?php

// Function to get client IP
function getClientIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    }
}

// Get IP and call API
$ip_address = getClientIP();
$url = "https://get-api.gungratech.com/?ip=" . $ip_address;

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$resp = curl_exec($curl);
curl_close($curl);

// Decode response
$data = json_decode($resp, true);

// Check if API response is successful
if ($data && $data['status'] == 'success') {
    $MARK_ip_address   = $data['ip'];
    $MARK_flag         = $data['flag'];
    $MARK_callingcode  = $data['callcode'];
    $MARK_continent    = $data['timezone'];
    $MARK_country      = $data['country'];
    $MARK_region       = $data['province'];
    $MARK_city         = $data['city'];
    $MARK_latitude     = $data['latitude'];
    $MARK_longitude    = $data['longitude'];
    $MARK_ccode        = $data['country_code'];
    $MARK_isp          = $data['isp'];
    $MARK_connection   = $data['connection'];
    $MARK_zip          = $data['zip'];
    $MARK_timezone     = $data['timezone'];
} else {
    echo "Error fetching data from API.";
}

?>
