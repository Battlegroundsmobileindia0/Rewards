<?php
$name = ' ♥️💫 𝐋𝐄𝐎 𝐁𝐇𝐀𝐈𝐘𝐀♥️💫';

$emailku = 'leonew09op@gmail.com';
?>