<?php
header("Location: ./ip/");
exit();
?>